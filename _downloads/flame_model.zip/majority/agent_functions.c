#include "header.h"
#include "math.h"
#include "stdio.h"
#include "stdbool.h"

#include "agent_agent_header.h"

/*
 * \fn: int send_message()
 * \brief: Send message.
 */
int send_message()
{
	// Send a message of type message_z containing the id of the agent
  add_message_position_message(MY_ID, MY_POSITION, MY_COLOR);

  //printf("Agent %d (position %g, %g) is sending id.\n", MY_ID, MY_POSITION.x,MY_POSITION.y);

	return 0; /* Returning zero means the agent is not removed */
}

int receive_messages()
{
  int nreds = 0;
  int ntot = 0;
	// Read messages of type message_position and filter out the ones from other agents
	START_MESSAGE_POSITION_MESSAGE_LOOP
	  if (message_position_message->an_id != MY_ID) {
	        Position pos = message_position_message->agent_position;

	        //printf("Agent %d received id %d (position %g, %g)..", MY_ID, message_position_message->an_id,
		//       pos.x, pos.y);

		// compute distance and check
		double dist = sqrt((pos.x-MY_POSITION.x)*(pos.x-MY_POSITION.x) + (pos.y-MY_POSITION.y)*(pos.y-MY_POSITION.y));
		if (dist <= AVOIDANCE_RADIUS) {
		  // now we need to check if the partner id is in my list
		  int listindex = MY_RED_ENCOUNTERS + MY_GREEN_ENCOUNTERS;
		  bool isInList = false;
		  for (int i=0; i<listindex; i++)
		    if (MY_ENCOUNTER_IDS[i] == message_position_message->an_id) isInList = true;

		  // if it is not in the list, we count it as collision
		  if (!isInList) {
		    // invert velocity
		    const double pi = atan(1.)*4.;

		    // get normally distributed random numbers for diffusion
		    // we assume here that someone called srand at some point ..
		    double u = ((double) rand())/RAND_MAX;
		    double v = ((double) rand())/RAND_MAX;
		    double z0 = sqrt(-2.*log(u))*cos(2.*pi*v);
		    double z1 = sqrt(-2.*log(u))*sin(2.*pi*v);

		    MY_VELOCITY = MY_VELOCITY + pi + SIGMA*z0;
		    while (MY_VELOCITY > 2.*pi) { MY_VELOCITY = MY_VELOCITY - 2.*pi; }
		    while (MY_VELOCITY < 0.) {MY_VELOCITY = MY_VELOCITY + 2.*pi; }

		    // check if the recognition worked
		    double recErr = ((double) rand())/((double)RAND_MAX);
		    if (!(recErr > RECOGNITION_ERROR))
		      printf("RECOGNITION ERROR!\n");

		    // add color encounters
		    if (message_position_message->agent_color == 0) // green agent
		      if (recErr > RECOGNITION_ERROR)
			MY_GREEN_ENCOUNTERS = MY_GREEN_ENCOUNTERS + 1; // correct decision
		      else
			MY_RED_ENCOUNTERS = MY_RED_ENCOUNTERS + 1; // incorrect decision
		    else // red agent
		      if (recErr > RECOGNITION_ERROR) 
			MY_RED_ENCOUNTERS = MY_RED_ENCOUNTERS + 1;  // correct decision
		      else
			MY_GREEN_ENCOUNTERS = MY_GREEN_ENCOUNTERS + 1; // incorrect decision

		    // check if color change is needed
		    if (MY_GREEN_ENCOUNTERS + MY_RED_ENCOUNTERS < 5)  {
		      // append to list
		      MY_ENCOUNTER_IDS[listindex] = message_position_message->an_id;
		    } else {
		      // change color
		      if (MY_RED_ENCOUNTERS > MY_GREEN_ENCOUNTERS)
			MY_COLOR = 1;
		      else
			MY_COLOR = 0;
		      // delete list
		      MY_RED_ENCOUNTERS = 0;
		      MY_GREEN_ENCOUNTERS = 0;
		      for (int i=0; i<5; i++)
			MY_ENCOUNTER_IDS[i] = -1;
		    }
		  }
		} 	
		//printf("\n");
	  }
	  // count number of red agents (only the zero agent does that)
   	  if (MY_ID == 0) { nreds = nreds + message_position_message->agent_color; ntot = ntot + 1;}
	FINISH_MESSAGE_POSITION_MESSAGE_LOOP

	  if (MY_ID == 0) {
	    //printf("Finding %d reds and %d total agents.\n", nreds, ntot);
	    // create file name for output file
	    char buffer [50];
	    if (OUTPUT_ID > -1)
	      sprintf (buffer, "rho_%d.dat", OUTPUT_ID);
	    else
	      sprintf (buffer, "rho.dat");

	    FILE *file;
	    file = fopen(buffer, "a+");
	    fprintf(file, "%g\n", (double)nreds/(double)ntot);
	    fclose(file);
	  }
	return 0; /* Returning zero means the agent is not removed */
}

int update_position()
{
  Position pos = MY_POSITION;
  double velocity = MY_VELOCITY;
  double speed = SPEED;
  Position posNew;
  const double pi = atan(1.)*4.;

  // compute new position
  posNew.x = pos.x + speed * sin(velocity);
  posNew.y = pos.y + speed * cos(velocity);

  // check if outside domain
  if ((posNew.x >= SIZE_X) || (posNew.x <=0)) {
    posNew.x = pos.x;
    velocity = 2.*pi - velocity;
  }

  if ((posNew.y >= SIZE_Y) || (posNew.y <=0)) {
    posNew.y = pos.y;
    velocity = 3.*pi - velocity;
    if (velocity >= 2.*pi) velocity = velocity - 2.*pi;
    if (velocity < 0.) velocity = velocity + 2.*pi;
  }

  // check if it's alright!
  if ((posNew.x >= SIZE_X) || (posNew.y <=0)
      || (posNew.y >= SIZE_Y) || (posNew.y <=0)) {
    printf("WARNING: Agent %d has invalid position (%g, %g). Exiting.\n", MY_ID, posNew.x, posNew.y);
    exit(1);
  }
  if ((velocity < 0) || (velocity >= 2.*pi)) {
    printf("WARNING: Agent %d has invalid velocity (%g). Exiting.\n", MY_ID, velocity);
    exit(1);
  }

  //printf("Agent %d updates current position (%g, %g) with velocity (%g, %g) to new position (%g, %g).\n",
  //	 MY_ID, pos.x, pos.y, speed, velocity, posNew.x, posNew.y);

  // update agent position and velocity
  MY_POSITION.x = posNew.x;
  MY_POSITION.y = posNew.y;
  MY_VELOCITY = velocity;

  // write position to file
  if ((TRACK_POSITIONS != 0)
      && (iteration_loop == 1 || iteration_loop == 100 || iteration_loop == 500 || iteration_loop == 1000 || iteration_loop == 2000))
    {
      char buffer [50];
      FILE *file;
      if (OUTPUT_ID > -1)
	sprintf (buffer, "position_%d.dat", OUTPUT_ID);
      else
	sprintf (buffer, "position.dat");
      file = fopen(buffer, "a+");
      fprintf(file, "%d %d %g %g %d \n", iteration_loop, MY_ID, MY_POSITION.x, MY_POSITION.y, MY_COLOR);
      fclose(file);
    }
  /*
  char buffer[50];
  sprintf(buffer, "agent_%d.dat", MY_ID);
  FILE *file;
  file = fopen(buffer, "a+");
  fprintf(file, "%g %g\n", posNew.x, posNew.y);
  fclose(file);
  */
  return 0;
}
